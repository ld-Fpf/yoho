<?php
//开启调试模型
define('DEBUG',True);
//显示DEBUG面板
define('DEBUG_TOOL',true);
//指量创建模块
define('MODULE_LIST','Index,Admin');
//应用目录
define('APP_PATH','Application/');
//引入框架
require 'hdphp/hdphp.php';